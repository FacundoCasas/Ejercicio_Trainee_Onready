package ejercicio;

import java.util.Arrays;

public class Test {
	
	public static void main(String[] args) {
		Auto auto1 = new Auto("Peugeot","206",200000.00,4);
		Auto auto2 = new Auto("Peugeot","208",250000.00,5);
		Moto moto1 = new Moto("Honda","Titan",60000.00,"125cc");
		Moto moto2 = new Moto("Yamaha","YBR",80500.50,"160cc");
		Concesionaria concesionaria = new Concesionaria(Arrays.asList(auto1,auto2,moto1,moto2));
		
		concesionaria.listarVehiculos();		
		concesionaria.vehiculoMasCaro();
		concesionaria.vehiculoMasBarato();
		concesionaria.modelosConPalabra("Y");
		concesionaria.vehiculosOrdenadosDeMenorAMayor();
	}
	
}
	