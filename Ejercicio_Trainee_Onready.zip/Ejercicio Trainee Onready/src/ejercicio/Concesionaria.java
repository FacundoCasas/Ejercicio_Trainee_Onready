package ejercicio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Concesionaria {
	
	private List<Vehiculo> vehiculos;

	public Concesionaria() {		
		this.vehiculos = new ArrayList<>();
	}
	
	public Concesionaria(List<Vehiculo> vehiculos) {		
		this.vehiculos = vehiculos;
	}
	
	public void listarVehiculos() {
		for (Vehiculo vehiculo : vehiculos) {
			System.out.println(vehiculo.toString() + " // Precio: $" + vehiculo.getPrecio());
		}
		System.out.println("=============================");
	}
	
	public void modelosConPalabra(String comparacion){
		boolean verdadero = false;
		for (Vehiculo vehiculo : vehiculos) {
			verdadero = vehiculo.getModelo().contains(comparacion);
			if (verdadero == true) {
				System.out.println(String.format("Veh�culo que contiene en el modelo la letra �%s�: %s %s $%s", comparacion, vehiculo.getMarca(), vehiculo.getModelo(), vehiculo.getPrecio()));
			}
		}
	}
	
	public void vehiculoMasCaro() {
		double max = 0;
		Vehiculo vehiculoMaximo = null;
		for (Vehiculo vehiculo : vehiculos) {
			if (vehiculo.getPrecio() > max) {
				max = vehiculo.getPrecio();
				vehiculoMaximo = vehiculo;
			}			
		}
		System.out.println(String.format("Veh�culo m�s caro:%s %s", vehiculoMaximo.getMarca(),vehiculoMaximo.getModelo()));
	}
	
	public void vehiculoMasBarato() {
		double min = 9999999;
		Vehiculo vehiculoMinimo = null;
		for (Vehiculo vehiculo : vehiculos) {
			if (vehiculo.getPrecio() < min) {
				min = vehiculo.getPrecio();
				vehiculoMinimo = vehiculo;
			}			
		}
		System.out.println(String.format("Veh�culo m�s barato:%s %s", vehiculoMinimo.getMarca(),vehiculoMinimo.getModelo()));
	}
	
	public void vehiculosOrdenadosDeMenorAMayor(){
		System.out.println("=============================");
		System.out.println("Veh�culos ordenados por precio de mayor a menor:");
		Collections.sort(vehiculos);
		for (Vehiculo vehiculo : vehiculos) {
			System.out.println(vehiculo.toString2());
		}		
	}
}
