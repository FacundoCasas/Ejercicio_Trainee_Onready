package ejercicio;

public class Vehiculo implements Comparable<Vehiculo> {

	private String marca;
	private String modelo;
	private double precio;
	
	public Vehiculo(String marca, String modelo, double precio) {
		this.marca = marca;
		this.modelo = modelo;
		this.precio = precio;	
	}
	
	@Override
	public String toString() {
		return "Marca: " + marca + " // Modelo: " + modelo ;
	}
	
	
	public String toString2() {
		return marca + " " + modelo ;
	}

	public String getMarca() {
		return marca;
	}
	
	public String getModelo() {
		return modelo;
	}
	
	public double getPrecio() {
		return precio;
	}
	
    @Override
    public int compareTo(Vehiculo o) {
        if (precio < o.precio) {
            return 1;
        }
        if (precio > o.precio) {
            return -1;
        }
        return 0;
    }
   
}
